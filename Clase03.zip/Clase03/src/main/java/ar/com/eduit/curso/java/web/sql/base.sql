drop database if exists javaWeb;
create database javaWeb;
use javaWeb;
create table articulos(
    id int primary key,
    descripcion varchar(30),
    precio double
);

select * from articulos;