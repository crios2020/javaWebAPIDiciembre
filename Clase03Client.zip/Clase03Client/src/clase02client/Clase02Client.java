package clase02client;
import ar.com.eduit.curso.java.web.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.util.List;

public class Clase02Client {

    public static void main(String[] args) throws Exception {
        
        //Cliente HTTP
        //String url="http://localhost:8086/Clase03/ArticuloAlta?id=14&descripcion=Monitor&precio=23000";
        //String url="http://localhost:8086/Clase03/ArticuloAll";
        //String url="http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=medrano%20162";
        
        //String response = response(url);
        
        //System.out.println(response);
        
        //System.out.println(response("http://localhost:8086/Clase03/ArticuloAlta?id=21&descripcion=Teclado&precio=3000"));
        //System.out.println(response("http://localhost:8086/Clase03/ArticuloAlta?id=23&descripcion=ParlanteBT&precio=2000"));
        //System.out.println(response("http://localhost:8086/Clase03/ArticuloAlta?id=24&descripcion=CableHDMI&precio=500"));
        
        System.out.println(response(
                "http://localhost:8086/Clase03/resources/articulos/v1/alta?id=220&descripcion=Tablet&precio=3000"));
        System.out.println(response(
                "http://localhost:8086/Clase03/resources/articulos/v1/alta?id=221&descripcion=PS5&precio=3000"));
        System.out.println(response(
                "http://localhost:8086/Clase03/resources/articulos/v1/alta?id=222&descripcion=CableVGA&precio=500"));
        
        
        
        //String url="http://localhost:8086/Clase03/ArticuloAll";
        String url="http://localhost:8086/Clase03/resources/articulos/v1/all";
        //Type LisType=new TypeToken<List<Articulo>>(){}.getType();
        //List<Articulo>list=new Gson().fromJson(response, LisType);
        //list.forEach(System.out::println);
        
        List<Articulo>list=new Gson()
                .fromJson(response(url), new TypeToken<List<Articulo>>(){}.getType());
        list.forEach(System.out::println);
        
        System.out.println("***************************************************");
        url="http://localhost:8086/Clase03/resources/articulos/v1/likeDescripcion?descripcion=par";
        list=new Gson()
                .fromJson(response(url), new TypeToken<List<Articulo>>(){}.getType());
        list.forEach(System.out::println);
    }

    private static String response(String url) throws IOException, InterruptedException {
        HttpClient client=HttpClient.newHttpClient();
        HttpRequest request=HttpRequest.newBuilder().uri(URI.create(url)).build();
        HttpResponse<String>response=client.send(request, HttpResponse.BodyHandlers.ofString());
        return response.body();
    }
    
}
