drop database if exists javaWeb;
create database javaWeb;
use javaWeb;
create table articulos(
    id int primary key,
    descripcion varchar(30),
    precio double
);

create table clientes(
    id int primary key auto_increment,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    tipoCliente enum('MINORISTA','MAYORISTA')
);

create table vendedores(
    id int primary key auto_increment,
    nroLegajo int not null,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    estadoCivil enum ('SOLTERO','CASADO','VIUDO','DIVORCIADO')
);

select * from articulos;

show tables;