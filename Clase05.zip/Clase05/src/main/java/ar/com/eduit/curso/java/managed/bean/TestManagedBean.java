package ar.com.eduit.curso.java.managed.bean;

import ar.com.eduit.curso.java.web.api.enums.EstadoCivil;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("testMB")
@SessionScoped
public class TestManagedBean implements Serializable{
    private String nombre="xxxx";

    public List<EstadoCivil>getEstados(){
        return Arrays.asList(EstadoCivil.values());
    }
    
    public TestManagedBean() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
}
