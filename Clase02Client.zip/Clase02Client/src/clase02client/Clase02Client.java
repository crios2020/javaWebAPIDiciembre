package clase02client;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;

public class Clase02Client {

    public static void main(String[] args) throws Exception {
        
        //Cliente HTTP
        //String url="http://localhost:8086/Clase02/ArticuloAlta?id=14&descripcion=Monitor&precio=23000";
        String url="http://localhost:8086/Clase02/ArticuloAll";
        //String url="http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=medrano%20162";
        
        HttpClient client=HttpClient.newHttpClient();
        HttpRequest request=HttpRequest.newBuilder().uri(URI.create(url)).build();
        HttpResponse<String>response=client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println(response.body());
        
        
        
    }
    
}
