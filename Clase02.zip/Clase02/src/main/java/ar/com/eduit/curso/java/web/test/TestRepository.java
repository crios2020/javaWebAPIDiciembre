package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.list.ArticuloRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_ArticuloRepository ar=new ArticuloRepository();
        ar.save(new Articulo(1,"Celular J5",20000));
        ar.save(new Articulo(2,"Parlante USB",10000));
        ar.save(new Articulo(3,"Mouse Optico",2000));
        ar.save(new Articulo(4,"Celular J8",50000));
        ar.save(new Articulo(5,"Monitor LCD 19",20000));
        
        //ar.getAll().forEach(System.out::println);
        ar.getLikeDescripcion("ar").forEach(System.out::println);
        
        
    }
}
