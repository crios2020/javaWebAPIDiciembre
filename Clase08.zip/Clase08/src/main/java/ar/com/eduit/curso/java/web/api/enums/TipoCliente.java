package ar.com.eduit.curso.java.web.api.enums;
public enum TipoCliente { MINORISTA, MAYORISTA }