package ar.com.eduit.curso.java.web.repositories.rest;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepository implements I_ClienteRepository{

    private String url;

    public ClienteRepository(String url) {
        this.url = url;
    }
    
    @Override
    public void save(Cliente cliente) {
        String url2=url+"/alta?nombre="+cliente.getNombre()+
                "&apellido="+cliente.getApellido()+
                "&tipoCliente="+cliente.getTipoCliente();
        String resp=new Service().response(url2);
        try{
        cliente.setId(Integer.parseInt(resp));
        }catch(Exception e){
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
    }

    @Override
    public List<Cliente> getAll() {
        List<Cliente>list=new ArrayList();
        try {
            list=new Gson()
                .fromJson(new Service().response(url+"/all"), 
                        new TypeToken<List<Cliente>>(){}.getType());
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
        return list;
    }

    @Override
    public List<Cliente> getLikeNombreApellido(String nombre, String apellido) {
        List<Cliente>list=new ArrayList();
        try {
            list=new Gson()
                .fromJson(new Service().response(
                        url+"/likeNombreApellido?nombre="+nombre+"&apellido="+apellido), 
                        new TypeToken<List<Cliente>>(){}.getType());
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
        return list;
    }

    @Override
    public List<Cliente> getLikeApellido(String apellido) {
        List<Cliente>list=new ArrayList();
        try {
            list=new Gson()
                .fromJson(new Service().response(
                        url+"/likeApellido?apellido="+apellido), 
                        new TypeToken<List<Cliente>>(){}.getType());
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
        return list;
    }

    @Override
    public Cliente getById(int id) {
        Cliente cliente = new Cliente();
        try {
            cliente=new Gson()
                .fromJson(new Service().response(
                        url+"/byId?id="+id), 
                        new TypeToken<Cliente>(){}.getType());
        } catch (Exception e) {
            System.out.println("*********************************************");
            System.out.println(e);
            System.out.println("*********************************************");
        }
        return cliente;
    }

}