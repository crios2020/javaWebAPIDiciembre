package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.api.enums.TipoCliente;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.rest.ClienteRepository;

public class TestRepositoryService {
    public static void main(String[] args) {
        I_ClienteRepository cr=new ClienteRepository("http://localhost:8086/Clase07/resources/clientes/v1");
        //Cliente cliente=new Cliente("Daniela","Correa",TipoCliente.MAYORISTA);
        //cr.save(cliente);
        //System.out.println(cliente);
        
        cr.getAll().forEach(System.out::println);
        
        System.out.println("*************************************************");
        
        System.out.println(cr.getById(22));
        
        System.out.println("*************************************************");
        
        cr.getLikeApellido("co").forEach(System.out::println);
        
        System.out.println("*************************************************");
        
        cr.getLikeNombreApellido("El", "Co").forEach(System.out::println);
    }
}