package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.api.enums.TipoCliente;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.entities.DetallePedido;
import ar.com.eduit.curso.java.web.entities.Pedido;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_DetallePedidoRepository;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_PedidoRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.Connector;
import ar.com.eduit.curso.java.web.repositories.jdbc.DetallePedidoRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.PedidoRepository;
//import ar.com.eduit.curso.java.web.repositories.list.ArticuloRepository;

public class TestRepository {
    public static void main(String[] args) {
        //I_ArticuloRepository ar=new ArticuloRepository();
        I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
        ar.save(new Articulo(1,"Celular J5",20000));
        ar.save(new Articulo(2,"Parlante USB",10000));
        ar.save(new Articulo(3,"Mouse Optico",2000));
        ar.save(new Articulo(4,"Celular J8",50000));
        ar.save(new Articulo(5,"Monitor LCD 19",20000));
        
        ar.getAll().forEach(System.out::println);
        //ar.getLikeDescripcion("ar").forEach(System.out::println);
        
        I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
        Cliente cliente=new Cliente("Cristian","Molina",TipoCliente.MAYORISTA);
        cr.save(cliente);
        System.out.println(cliente);
        
        System.out.println("*************************************************");
        cr.getAll().forEach(System.out::println);
        //cr.getLikeApellido("ca").forEach(System.out::println);
        
        System.out.println("*************************************************");
        I_PedidoRepository pr=new PedidoRepository(Connector.getConnection());
        
        Pedido pedido=new Pedido(java.sql.Date.valueOf("2021-01-21"), 2);
        
        pr.save(pedido);
        
        System.out.println(pedido);
        
        System.out.println("*************************************************");
        pr.getAll().forEach(System.out::println);
        System.out.println("*************************************************");
        pr.getByCliente(cr.getById(1)).forEach(System.out::println);
        
        System.out.println("*************************************************");
        I_DetallePedidoRepository dr=new DetallePedidoRepository(Connector.getConnection());
        
        DetallePedido detalle1=new DetallePedido(pedido.getId(),1,10);
        DetallePedido detalle2=new DetallePedido(pedido.getId(),3,5);
        DetallePedido detalle3=new DetallePedido(pedido.getId(),5,2);
        DetallePedido detalle4=new DetallePedido(pedido.getId(),100,1);
        
        dr.save(detalle1);
        dr.save(detalle2);
        dr.save(detalle3);
        dr.save(detalle4);
        
        System.out.println("*************************************************");
        dr.getAll().forEach(System.out::println);
        System.out.println("*************************************************");
        System.out.println(pr.getById(7));
        dr.getByPedido(pr.getById(7)).forEach(System.out::println);
        System.out.println("*************************************************");
        dr.getByPedido(pr.getById(8)).forEach(d->
                System.out.println(
                                pr.getById(d.getIdPedido())+"\t"+
                                ar.getById(d.getIdArticulo())+"\t Cantidad: "+
                                d.getCantidad())
        );
        
    }
}
