package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.Connector;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("articulos/v1")
public class ArticuloService {
    I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "servicio articulos v1 activo";
    }
    
    @GET
    @Path("alta")
    @Produces(MediaType.TEXT_PLAIN)
    public String alta( @QueryParam("id")int id, 
                        @QueryParam("descripcion")String descripcion, 
                        @QueryParam("precio")double precio
    ){
        Articulo articulo=new Articulo(id, descripcion, precio);
        ar.save(articulo);
        return "true";
    }
    
    @GET
    @Path("baja")
    @Produces(MediaType.TEXT_PLAIN)
    public String baja( @QueryParam("id")int id, 
                        @QueryParam("descripcion")String descripcion, 
                        @QueryParam("precio")double precio
    ){
        Articulo articulo=new Articulo(id, descripcion, precio);
        ar.remove(articulo);
        return "true";
    }
    
    @GET
    @Path("all")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        return new Gson().toJson(ar.getAll());
    }
    
    @GET
    @Path("likeDescripcion")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeDescripcion(@QueryParam("descripcion")String descripcion){
        return new Gson().toJson(ar.getLikeDescripcion(descripcion));
    }
    
}
