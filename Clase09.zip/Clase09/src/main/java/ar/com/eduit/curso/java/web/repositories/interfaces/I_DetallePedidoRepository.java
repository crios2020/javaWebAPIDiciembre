package ar.com.eduit.curso.java.web.repositories.interfaces;

import ar.com.eduit.curso.java.web.entities.DetallePedido;
import ar.com.eduit.curso.java.web.entities.Pedido;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_DetallePedidoRepository {
    void save(DetallePedido detalle);
    List<DetallePedido>getAll();
    default List<DetallePedido>getByPedido(Pedido pedido){
        if(pedido==null) return new ArrayList<DetallePedido>();
        return getAll()
                .stream()
                .filter(d->d.getIdPedido()==pedido.getId())
                .collect(Collectors.toList());
    }
}