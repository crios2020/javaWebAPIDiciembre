package ar.com.eduit.curso.java.web.rest;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("test")
public class Test {
    
    
    //http://localhost:8086/Clase03/resources/test
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio REST Activo";
    }
    
    //http://localhost:8086/Clase03/resources/test/info2
    @GET
    @Path("info2")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "Servicio REST Activo 2";
    }
    
}
