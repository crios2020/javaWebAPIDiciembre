package ar.com.eduit.curso.java.web.rest;

import ar.com.eduit.curso.java.web.api.enums.TipoCliente;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.Connector;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("clientes/v1")
public class ClienteService {
    
    private I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
    
    @GET
    public String info(){
        return "Servicio Clientes Activos!";
    }
    
    @Path("alta")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String alta(
            @QueryParam("nombre") String nombre, 
            @QueryParam("apellido") String apellido, 
            @QueryParam("tipoCliente")String tipoCliente
    ){
        if(         nombre==null        || nombre.length() < 3
                ||  apellido==null      || apellido.length() < 3
                ||  tipoCliente==null
                ){
            return "0";
        }
        try{
            Cliente cliente = new Cliente(nombre, apellido, TipoCliente.valueOf(tipoCliente.toUpperCase()));
            cr.save(cliente);
            return cliente.getId()+"";
        }catch(Exception e){
            return "0";
        }
    }
    
    @Path("all")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        return new Gson().toJson(cr.getAll());
    }
    
    @Path("byId")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getById(@QueryParam("id") int id){
        return new Gson().toJson(cr.getById(id));
    }
    
    @Path("likeApellido")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeApellido(@QueryParam("apellido") String apellido){
        return new Gson().toJson(cr.getLikeApellido(apellido));
    }
    
    @Path("likeNombreApellido")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeNombreApellido(@QueryParam("nombre")String nombre,@QueryParam("apellido") String apellido){
        return new Gson().toJson(cr.getLikeNombreApellido(nombre, apellido));
    }
}
