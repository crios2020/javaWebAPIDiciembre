package ar.com.eduit.curso.java.managed.bean;

import ar.com.eduit.curso.java.web.api.enums.EstadoCivil;
import ar.com.eduit.curso.java.web.api.enums.TipoCliente;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.Connector;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named("clienteMB")
@SessionScoped
public class ClienteManagedBean  implements Serializable{
    private I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
    private Cliente cliente=new Cliente();
    private String mensaje="";
    private String buscarNombre="";
    private String buscarApellido="";
    private int idArticulo=0;

    public ClienteManagedBean() {
    }

    public void save(){
        cr.save(cliente);
        mensaje="Se guardo un cliente id: "+cliente.getId();
        cliente=new Cliente();
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje, "titulo");
        FacesContext.getCurrentInstance().addMessage(null, message);
        //FacesContext.getCurrentInstance().addMessage(null, message);
        //FacesContext.getCurrentInstance().addMessage(null, 
        //        new FacesMessage(FacesMessage.SEVERITY_INFO, "HOLAAAAA!",null));
    }
    
    public List<Cliente>getAll(){
        return cr.getAll();
    }
    
    public List<Cliente>getLikeApellido(){
        return cr.getLikeApellido(buscarApellido);
    }
    
    public List<Cliente>getLikeNombreApellido(){
        return cr.getLikeNombreApellido(buscarNombre, buscarApellido);
    }
    
    public List<TipoCliente>getTipos(){
        return Arrays.asList(TipoCliente.values());
    }
    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getBuscarApellido() {
        return buscarApellido;
    }

    public void setBuscarApellido(String buscarApellido) {
        this.buscarApellido = buscarApellido;
    }

    public int getIdArticulo() {
        return idArticulo;
    }

    public void setIdArticulo(int idArticulo) {
        this.idArticulo = idArticulo;
    }

    public String getBuscarNombre() {
        return buscarNombre;
    }

    public void setBuscarNombre(String buscarNombre) {
        this.buscarNombre = buscarNombre;
    }
 
}
