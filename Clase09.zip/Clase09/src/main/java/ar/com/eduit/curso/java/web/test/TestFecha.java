package ar.com.eduit.curso.java.web.test;

import java.sql.Date;



public class TestFecha {
    public static void main(String[] args) {
        Date date=Date.valueOf("2021-01-21");
        System.out.println(date);
    }
}