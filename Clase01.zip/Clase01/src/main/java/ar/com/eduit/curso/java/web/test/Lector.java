package ar.com.eduit.curso.java.web.test;

import java.io.Closeable;
import java.io.IOException;

public class Lector implements Closeable {

    public Lector (){
        
    }
    
    public String leer(){
        return "texto";
    }
    
    @Override
    public void close() throws IOException {
        System.out.println("Se cerro el lector");
    }
    
}
