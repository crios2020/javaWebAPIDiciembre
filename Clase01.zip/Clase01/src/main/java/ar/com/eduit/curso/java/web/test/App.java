package ar.com.eduit.curso.java.web.test;

public class App {
    public static void main(String[] args) {
        try(Lector lector=new Lector()){          //Try with Resources JDK 7
            System.out.println(lector.leer());
            throw new Exception();
        }catch(Exception e){
            
        }
    }
}
