package ar.com.eduit.curso.java.web.api.enums;
public enum EstadoCivil {
    SOLTERO,CASADO,VIUDO,DIVORCIADO
}
