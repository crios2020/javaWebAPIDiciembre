package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.repositories.jpa.AlumnoRepository;
import ar.org.centro8.curso.java.repositories.jpa.CursoRepository;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class TestRepositories {
    public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        I_CursoRepository cr=new CursoRepository(emf);
        /*
        Curso curso=new Curso("Python","Juarez","LUNES","MAÑANA");
        cr.save(curso);
        System.out.println(curso);
        
        //System.out.println(cr.getById(12));
        
        //cr.remove(cr.getById(12));
        
        
        curso=cr.getById(13);
        if(curso!=null){
            curso.setTitulo(".NET");
            curso.setProfesor("Pedro");
            cr.update(curso);
        }
        
        
        cr.getAll().forEach(System.out::println);
        //cr.getLikeTitulo("jav").forEach(System.out::println);
        */
        System.out.println("*************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(emf);
        
        //Alumno alumno=new Alumno("Herman","Mercado",28,cr.getById(1));
        //ar.save(alumno);
        //System.out.println(alumno);

        ar.remove(ar.getById(1));
        
        /*
        alumno=ar.getById(9);
        if(alumno!=null){
            alumno.setNombre("Victor");
            alumno.setIdCurso(cr.getById(1));
            ar.update(alumno);
        }
        */
        System.out.println("*************************************************");
        ar.getAll().forEach(System.out::println);
        //ar.getLikeApellido("me").forEach(System.out::println);
        //ar.getByCurso(cr.getById(5)).forEach(System.out::println);
        
        emf.close();
    }
}