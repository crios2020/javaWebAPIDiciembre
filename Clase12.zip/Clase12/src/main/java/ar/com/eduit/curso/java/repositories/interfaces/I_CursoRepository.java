package ar.com.eduit.curso.java.repositories.interfaces;

import ar.com.eduit.curso.java.entities.Curso;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_CursoRepository {
    void save(Curso curso);                             //insert
    void remove(Curso curso);                           //delete
    void update(Curso curso);                           //update
    Curso getById(int id);
    List<Curso> getAll();                               //select
    default List<Curso> getLikeTitulo(String titulo){
        //select * from cursos where titulo like '%titulo%';
        //List<Curso>list=new ArrayList();
        //if(titulo==null) return list; 
        //for(Curso c:getAll()){
        //    if(c.getTitulo().toLowerCase().contains(titulo.toLowerCase())){
        //        list.add(c);
        //    }
        //}
        //return list;
        if(titulo==null) return new ArrayList<Curso>(); 
        return getAll()
                .stream()
                .filter(c->c.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Curso> getLikeProfesor(String profesor){
        if(profesor==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getProfesor().toLowerCase().contains(profesor.toLowerCase()))
                .collect(Collectors.toList());
    }
    List<Curso> getLikeTituloAndProfesor(String titulo, String profesor);
    List<Curso> getLimit(int limit);
}
